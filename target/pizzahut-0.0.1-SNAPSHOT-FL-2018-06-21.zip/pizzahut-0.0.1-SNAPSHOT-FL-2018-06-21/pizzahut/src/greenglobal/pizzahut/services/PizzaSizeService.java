package greenglobal.pizzahut.services;

import java.util.List;

import greenglobal.pizzahut.entity.PizzaSize;

public interface PizzaSizeService {
	public List<PizzaSize> findAll();
}
