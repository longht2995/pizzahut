package greenglobal.pizzahut.services;

import java.util.List;

import greenglobal.pizzahut.entity.Category;

public interface CategoryService {
	public List<Category> findAll();
}
