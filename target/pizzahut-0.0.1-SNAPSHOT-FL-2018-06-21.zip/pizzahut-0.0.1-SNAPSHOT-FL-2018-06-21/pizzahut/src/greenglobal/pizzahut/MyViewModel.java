package greenglobal.pizzahut;

import java.util.ArrayList;
import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import greenglobal.pizzahut.entity.PizzaSize;
import greenglobal.pizzahut.services.PizzaSizeService;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MyViewModel {

	@WireVariable
	private PizzaSizeService pizzasizeService;
	private List<PizzaSize> pizzaSizeList;

	@Init
	public void init() {
		pizzaSizeList = new ArrayList<PizzaSize>();
		pizzaSizeList = pizzasizeService.findAll();
	}
	
	public List<PizzaSize> getPizzaSizeList() {
		return pizzaSizeList;
	}

	public void setPizzaSizeList(List<PizzaSize> pizzaSizeList) {
		this.pizzaSizeList = pizzaSizeList;
	}
	


}
